import React from 'react';

export class Error404 extends React.Component {
    render() {
        return (
            <div class="no-page">Nothing here</div>
        )
    }
}